const express = require('express');
const stripe = require('stripe')('sk_test_yQGX7EoYdZ1KThGWMfDqd21d');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const mysql = require('mysql');

//can use localhost
const cors = require('cors');

const app = express();

app.use(cors());

//Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.post('/pay', (req, res) => {
  console.log(req.body);
  console.log(res);
})

//charge route
app.post('/charge', (req, res) => {
  console.log(req.body);
  const amount = Math.round(req.body.totalcost * 100);
  // gives back token, tokenType and email
  stripe.customers.create({
    email: req.body.stripeemail,
    source: req.body.stripid
  })
  .then(customer => stripe.charges.create({
    amount: amount,
    description:'BBQ Order Payment',
    currency:'sgd',
    customer: customer.id
  }))
  .then(charge => {
    let post = {id: charge.id, totalcost:req.body.totalcost};
    // console.log(charge);
    res.json(post);
  })
  .catch(err => {
    console.log(err);
  });
});

const port = process.env.PORT || 5010;
app.listen(port, () => {
  console.log(`Payment Service started on port ${port}`)
});





